# Sharma, Sagar
# 1001-626-958
# 2019-09-22
# Assignment-01-01

import numpy as np
import itertools

class Perceptron(object):
    def __init__(self, input_dimensions=2,number_of_classes=4,seed=None):
        """
        Initialize Perceptron model
        :param input_dimensions: The number of features of the input data, for example (height, weight) would be two features.
        :param number_of_classes: The number of classes.
        :param seed: Random number generator seed.
        """
        if seed != None:
            np.random.seed(seed)
        self.input_dimensions = input_dimensions
        self.number_of_classes = number_of_classes
        self._initialize_weights()
    def _initialize_weights(self):
        """
        Initialize the weights, initalize using random numbers.
        Note that number of neurons in the model is equal to the number of classes
        """
        self.number_of_neurons = self.number_of_classes

        self.weights = np.random.randn(self.number_of_neurons, self.input_dimensions + 1)


        # raise Warning("You must implement _initialize_weights! This function should initialize (or re-initialize) your model weights. Bias should be included in the weights")

    def initialize_all_weights_to_zeros(self):
        """
        Initialize the weights, initalize using random numbers.
        """
        self.weights = np.zeros([self.number_of_neurons, self.input_dimensions + 1])

        # raise Warning("You must implement this function! This function should initialize (or re-initialize) your model weights to zeros. Bias should be included in the weights")

    def predict(self, X):
        """
        Make a prediction on an array of inputs
        :param X: Array of input [input_dimensions,n_samples]. Note that the input X does not include a row of ones
        as the first row.
        :return: Array of model outputs [number_of_classes ,n_samples]
        """

        '''creating an output array'''
        self.Y_Predict = np.zeros([self.number_of_classes, X[0].size], int)
        #transpose so that we can iterate with input array
        self.Y_Predict = self.Y_Predict.transpose()

        '''adding the first row in the input array as all 1's'''
        self.X_train = np.concatenate((np.ones([1,X[0].size]),X))

        '''predict using hardlimit'''
        #transpose the input array for iterating
        self.X_train = self.X_train.transpose()


        #iterating over the samples
        for (input_sample, output) in zip(self.X_train, self.Y_Predict):
            #iterate over the predictions made by each neuron
            for neuron in range(self.number_of_neurons):
                prediction = None
                net = 0
                #iterate over the inputs in a sample and the corresponsing weights
                for (input, weight) in zip(input_sample, self.weights[neuron]):
                    #linear combination of weights and inputs
                    net = net + (input * weight)
                '''implement the hardlimit function'''
                if net >= 0:
                    prediction = 1
                else:
                    prediction = 0
                #update predict output array
                output[neuron] = prediction

        return(self.Y_Predict.transpose())

        # raise Warning("You must implement predict. This function should make a prediction on a matrix of inputs")


    def print_weights(self):
        """
        This function prints the weight matrix (Bias is included in the weight matrix).
        """
        print(self.weights)
        # raise Warning("You must implement print_weights")

    def train(self, X, Y, num_epochs=10, alpha=0.001):
        """
        Given a batch of data, and the necessary hyperparameters,
        this function adjusts the self.weights using Perceptron learning rule.
        Training should be repeted num_epochs time.
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [number_of_classes ,n_samples]
        :param num_epochs: Number of times training should be repeated over all input data
        :param alpha: Learning rate
        :return: None
        """


        for epoch in range(num_epochs):
            #call predict
            input = X
            #transpose the actual output to iterate intuitively
            self.Y_Predict = self.predict(input).transpose()

            #transpose the target output to iterate intuitively
            self.Y_train = Y.transpose()

            '''adding the first row in the input array as all 1's'''
            self.X_train = np.concatenate((np.ones([1,X[0].size]),X))
            #transpose the input array to iterate intuitively
            self.X_train = self.X_train.transpose()

            #iterating over the samples
            for (input_sample, T_Output, T_Output_row) in zip(self.X_train, self.Y_train, range(len(self.Y_train))):
                # iterate alongside the actual output array which is updated for each iteration
                A_Output = self.Y_Predict[T_Output_row]
                #iterate over the predictions made by each neuron
                for neuron in range(self.number_of_neurons):
                    error = T_Output[neuron] - A_Output[neuron]
                    #iterate over the inputs in a sample and the corresponsing weights
                    for (input, weight, weight_index) in zip(input_sample, self.weights[neuron], range(len(self.weights[neuron]))):
                        #update the weights
                        self.weights[neuron][weight_index] = weight + (alpha * error * input)
                #call predict
                input = X
                #transpose the actual output to iterate intuitively
                self.Y_Predict = self.predict(input).transpose()

        # raise Warning("You must implement train")

    def calculate_percent_error(self,X, Y):
        """
        Given a batch of data this function calculates percent error.
        For each input sample, if the output is not the same as the desired output, Y,
        then it is considered one error. Percent error is number_of_errors/ number_of_samples.
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [number_of_classes ,n_samples]
        :return percent_error
        """

        '''adding the first row in the input array as all 1's'''
        self.X_train = np.concatenate((np.ones([1,X[0].size]),X))
        #transpose the input array to iterate intuitively
        self.X_train = self.X_train.transpose()
        #transpose the target output to iterate intuitively
        self.Y_train = Y.transpose()
        #call predict
        input = X
        #transpose the actual output to iterate intuitively
        self.Y_Predict = self.predict(input).transpose()
        samples = 0
        mismatch_count = 0
        #iterating over the samples
        for (input_sample, T_Output, A_Output) in zip(self.X_train, self.Y_train, self.Y_Predict):
            samples = samples + 1
            #iterate over the predictions made by each neuron
            for neuron in range(self.number_of_neurons):
                if T_Output[neuron] != A_Output[neuron]:
                    mismatch_count = mismatch_count + 1
                    break
        percent_error = (mismatch_count/samples)
        return(percent_error)
        # raise Warning("You must implement calculate_percent_error")

if __name__ == "__main__":
    """
    This main program is a sample of how to run your program.
    You may modify this main program as you desire.
    """

    input_dimensions = 2
    number_of_classes = 2

    model = Perceptron(input_dimensions=input_dimensions, number_of_classes=number_of_classes, seed=1)
    X_train = np.array([[-1.43815556, 0.10089809, -1.25432937, 1.48410426],
                        [-1.81784194, 0.42935033, -1.2806198, 0.06527391]])
    print(model.predict(X_train))
    Y_train = np.array([[1, 0, 0, 1], [0, 1, 1, 0]])
    model.initialize_all_weights_to_zeros()
    print("****** Model weights ******\n",model.weights)
    print("****** Input samples ******\n",X_train)
    print("****** Desired Output ******\n",Y_train)
    percent_error=[]
    for k in range (20):
        model.train(X_train, Y_train, num_epochs=1, alpha=0.0001)
        percent_error.append(model.calculate_percent_error(X_train,Y_train))
    print("******  Percent Error ******\n",percent_error)
    print("****** Model weights ******\n",model.weights)

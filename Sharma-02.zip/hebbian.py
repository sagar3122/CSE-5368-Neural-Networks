# Sharma, Sagar
# 1001-626-958
# 2019-10-07
# Assignment-02-01

import numpy as np
import math
import itertools
import matplotlib
import matplotlib.pyplot as plt
import tensorflow as tf


def display_images(images):
    # This function displays images on a grid.
    # Farhad Kamangar Sept. 2019
    number_of_images=images.shape[0]
    number_of_rows_for_subplot=int(np.sqrt(number_of_images))
    number_of_columns_for_subplot=int(np.ceil(number_of_images/number_of_rows_for_subplot))
    for k in range(number_of_images):
        plt.subplot(number_of_rows_for_subplot,number_of_columns_for_subplot,k+1)
        plt.imshow(images[k], cmap=plt.get_cmap('gray'))
        # plt.imshow(images[k], cmap=pyplot.get_cmap('gray'))
    # plt.show()

def display_numpy_array_as_table(input_array):
    # This function displays a 1d or 2d numpy array (matrix).
    # Farhad Kamangar Sept. 2019
    if input_array.ndim==1:
        num_of_columns,=input_array.shape
        temp_matrix=input_array.reshape((1, num_of_columns))
    elif input_array.ndim>2:
        print("Input matrix dimension is greater than 2. Can not display as table")
        return
    else:
        temp_matrix=input_array
    number_of_rows,num_of_columns = temp_matrix.shape
    plt.figure()
    tb = plt.table(cellText=np.round(temp_matrix,2), loc=(0,0), cellLoc='center')
    for cell in tb.properties()['child_artists']:
        cell.set_height(1/number_of_rows)
        cell.set_width(1/num_of_columns)

    ax = plt.gca()
    ax.set_xticks([])
    ax.set_yticks([])
    plt.show()
class Hebbian(object):
    def __init__(self, input_dimensions=2,number_of_classes=4,transfer_function="Hard_limit",seed=None):
        """
        Initialize Perceptron model
        :param input_dimensions: The number of features of the input data, for example (height, weight) would be two features.
        :param number_of_classes: The number of classes.
        :param transfer_function: Transfer function for each neuron. Possible values are:
        "Hard_limit" ,  "Sigmoid", "Linear".
        :param seed: Random number generator seed.
        """
        if seed != None:
            np.random.seed(seed)
        self.input_dimensions = input_dimensions
        self.number_of_classes=number_of_classes
        self.transfer_function=transfer_function
        self._initialize_weights()
    def _initialize_weights(self):
        """
        Initialize the weights, initalize using random numbers.
        Note that number of neurons in the model is equal to the number of classes
        """
        self.number_of_neurons = self.number_of_classes
        self.weights = np.random.randn(self.number_of_neurons, self.input_dimensions + 1)
    def initialize_all_weights_to_zeros(self):
        """
        Initialize the weights, initalize using random numbers.
        """
        self.weights = np.zeros([self.number_of_neurons, self.input_dimensions + 1])
    def predict(self, X):
        """
        Make a prediction on an array of inputs
        :param X: Array of input [input_dimensions,n_samples]. Note that the input X does not include a row of ones
        as the first row.
        :return: Array of model outputs [number_of_classes ,n_samples]. This array is a numerical array.
        """
        '''creating an output array'''
        self.Y_Predict = np.zeros([self.number_of_classes, X[0].size])
        #transpose so that we can iterate with input array
        self.Y_Predict = self.Y_Predict.transpose()

        '''adding the first row in the input array as all 1's'''
        self.X_train = np.concatenate((np.ones([1,X[0].size]),X))

        # '''predict using hardlimit'''
        #transpose the input array for iterating
        self.X_train = self.X_train.transpose()

        #iterating over the samples
        for (input_sample, output) in zip(self.X_train, self.Y_Predict):
            #iterate over the predictions made by each neuron
            for neuron in range(self.number_of_neurons):
                prediction = None
                net = 0
                #iterate over the inputs in a sample and the corresponsing weights
                for (input, weight) in zip(input_sample, self.weights[neuron]):
                    #linear combination of weights and inputs
                    net = net + (input * weight)
                if self.transfer_function == 'Hard_limit':
                    prediction = self.hard_limit(net)
                elif self.transfer_function == 'Sigmoid':
                    prediction = self.sigmoid(net)
                elif self.transfer_function == 'Linear':
                    prediction = self.linear(net)
                #update predict output array
                output[neuron] = prediction
        #returing in the same shape as professor has given inputs in
        return(self.Y_Predict.transpose())

    '''hard limit'''
    def hard_limit(self, net):
        if net >= 0:
            prediction = 1
            return(prediction)
        else:
            prediction = 0
            return(prediction)

    '''sigmoid'''
    def sigmoid(self, net):
        net = np.array(-net)
        prediction = 1/(1 + np.exp(net))
        return(prediction)

    '''Linear'''
    def linear(self, net):
        prediction = net
        return(prediction)

    def print_weights(self):
        """
        This function prints the weight matrix (Bias is included in the weight matrix).
        """
        print(self.weights)

    def one_hot_encodify(self, y):
        onehot_encoded_y_train = list()
        for value in y:
            out = [0 for _ in range(self.number_of_classes)]
            out[value] = 1
            onehot_encoded_y_train.append(out)
        onehot_encoded_y_train = np.array(onehot_encoded_y_train)
        return(onehot_encoded_y_train)

    def train(self, X, y, batch_size=1,num_epochs=10,  alpha=0.1,gamma=0.9,learning="Delta"):
        """
        Given a batch of data, and the necessary hyperparameters,
        this function adjusts the self.weights using Perceptron learning rule.
        Training should be repeted num_epochs time.
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [n_samples]. This array includes the indexes of
        the desired (true) class.
        :param batch_size: number of samples in a batch
        :param num_epochs: Number of times training should be repeated over all input data
        :param alpha: Learning rate
        :param gamma: Controls the decay
        :param learning: Learning rule. Possible methods are: "Filtered", "Delta", "Unsupervised_hebb"
        :return: None
        """
        for epoch in range(num_epochs):
            # print('epoch : ', epoch)
            #call predict
            input = X
            #transpose the actual output to iterate intuitively
            self.Y_Predict = self.predict(input).transpose()

            #one hot encodify the target output to iterate intuitively
            self.Y_train = self.one_hot_encodify(y)

            '''adding the first row in the input array as all 1's for the bias input'''
            self.X_train = np.concatenate((np.ones([1,X[0].size]),X))
            #transpose the input array to iterate intuitively
            self.X_train = self.X_train.transpose()

            #no of batches
            batches = math.ceil(len(self.X_train)/batch_size)
            # print('batches : ', batches)

            #lower and upper indexes
            batch_lower_index = 0
            # print('batch_lower_index : ', batch_lower_index)
            batch_upper_index = batch_size
            # print('batch_upper_index : ', batch_upper_index)

            #iterate through the batches
            for i in range(batches):
                # print('batch : ', i)
                input_batch = self.X_train[batch_lower_index : batch_upper_index]
                T_Output_batch = self.Y_train[batch_lower_index : batch_upper_index]
                A_Output_batch = self.Y_Predict[batch_lower_index : batch_upper_index]
                error = np.subtract(T_Output_batch, A_Output_batch)
                if learning == 'Delta':
                    self.weights = self.delta_learning(self.weights, alpha, error, input_batch)
                elif learning == 'Filtered':
                    self.weights = self.filtered(self.weights, gamma, alpha, T_Output_batch, input_batch)
                elif learning == 'Unsupervised_hebb':
                    self.weights = self.Unsupervised_hebb(self.weights, alpha, A_Output_batch, input_batch)

                #update the actual outputs for each batch
                #call predict
                input = X
                #transpose the actual output to iterate intuitively
                self.Y_Predict = self.predict(input).transpose()
                batch_lower_index = batch_lower_index + batch_size
                # print('batch_lower_index : ', batch_lower_index)
                batch_upper_index = batch_upper_index + batch_size
                # print('batch_upper_index : ', batch_upper_index)


    def delta_learning(self, Weights, alpha, error, input_sample):
        Weights = np.add(Weights, ((((input_sample.transpose()).dot(error)).transpose()).dot(alpha)))
        return(Weights)

    def filtered(self, Weights, gamma, alpha, t_output, input_sample):
        Weights = np.add((Weights.dot((1 - gamma))), ((((input_sample.transpose()).dot(t_output)).transpose()).dot(alpha)))
        return(Weights)

    def Unsupervised_hebb(self, Weights, alpha, a_output, input_sample):
        Weights = np.add(Weights, ((((input_sample.transpose()).dot(a_output)).transpose()).dot(alpha)))
        return(Weights)


    def calculate_percent_error(self,X, y):
        """
        Given a batch of data this function calculates percent error.
        For each input sample, if the predicted class output is not the same as the desired class,
        then it is considered one error. Percent error is number_of_errors/ number_of_samples.
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [n_samples]. This array includes the indexes of
        the desired (true) class.
        :return percent_error
        """
        '''adding the first row in the input array as all 1's'''
        self.X_train = np.concatenate((np.ones([1,X[0].size]),X))
        #transpose the input array to iterate intuitively
        self.X_train = self.X_train.transpose()

        #one hot encoding
        self.Y_train = self.one_hot_encodify(y)

        #call predict
        input = X
        #transpose the actual output to iterate intuitively
        self.Y_Predict = self.predict(input).transpose()

        #converting to lists
        Ytrain = self.Y_train.tolist()
        YPredict = self.Y_Predict.tolist()

        samples = 0
        mismatch_count = 0
        #iterating over the samples
        for (input_sample, T_Output, A_Output) in zip(self.X_train, Ytrain, YPredict):
            samples = samples + 1
            if np.argmax(T_Output) != np.argmax(A_Output):
                mismatch_count = mismatch_count + 1
        percent_error = (mismatch_count/samples)
        return(percent_error)
        # raise Warning("You must implement calculate_percent_error")

    def calculate_confusion_matrix(self,X,y):
        """
        Given a desired (true) output as one hot and the predicted output as one-hot,
        this method calculates the confusion matrix.
        If the predicted class output is not the same as the desired output,
        then it is considered one error.
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [n_samples]. This array includes the indexes of
        the desired (true) class.
        :return confusion_matrix[number_of_classes,number_of_classes].
        Confusion matrix should be shown as the number of times that
        an image of class n is classified as class m where 1<=n,m<=number_of_classes.
        """
        '''adding the first row in the input array as all 1's'''
        self.X_test = np.concatenate((np.ones([1,X[0].size]),X))
        #transpose the input array to iterate intuitively
        self.X_test = self.X_test.transpose()

        #one hot encoding
        self.Y_test = self.one_hot_encodify(y)

        #call predict
        input = X
        #transpose the actual output to iterate intuitively
        self.Y_Predict = self.predict(input).transpose()

        confusion_matrix = np.zeros(shape = (self.number_of_classes, self.number_of_classes))

        for row1, row2 in zip(self.Y_test, self.Y_Predict):
            i = np.argmax(row1)
            j = np.argmax(row2)
            confusion_matrix[i][j] += 1
        return(confusion_matrix)



if __name__ == "__main__":

    # Read mnist data
    number_of_classes = 10
    number_of_training_samples_to_use = 1000
    number_of_test_samples_to_use = 100
    (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
    X_train_vectorized=((X_train.reshape(X_train.shape[0],-1)).T)[:,0:number_of_training_samples_to_use]
    y_train = y_train[0:number_of_training_samples_to_use]
    X_test_vectorized=((X_test.reshape(X_test.shape[0],-1)).T)[:,0:number_of_test_samples_to_use]
    y_test = y_test[0:number_of_test_samples_to_use]
    number_of_images_to_view=16
    test_x=X_train_vectorized[:,0:number_of_images_to_view].T.reshape((number_of_images_to_view,28,28))
    display_images(test_x)
    input_dimensions=X_test_vectorized.shape[0]
    # print(input_dimensions)
    model = Hebbian(input_dimensions=input_dimensions, number_of_classes=number_of_classes,
                    transfer_function="Hard_limit",seed=5)
    model.initialize_all_weights_to_zeros()
    # print('X train\n', X_train_vectorized)
    # print(X_train_vectorized.shape)
    # print('y train\n', y_train)
    # y_train = model.one_hot_encodify(y_train)
    # print(y_train)
    # print(y_train.shape)
    # prediction = model.predict(X_train_vectorized)
    # print(prediction)
    # print(prediction.shape)
    # print(prediction.transpose())
    # print(prediction.transpose().shape)
    percent_error=[]
    for k in range (10):
        model.train(X_train_vectorized, y_train,batch_size=300, num_epochs=2, alpha=0.1,gamma=0.1,learning="Delta")
        percent_error.append(model.calculate_percent_error(X_test_vectorized,y_test))
    print("******  Percent Error ******\n",percent_error)
    confusion_matrix=model.calculate_confusion_matrix(X_test_vectorized,y_test)
    print(np.array2string(confusion_matrix, separator=","))

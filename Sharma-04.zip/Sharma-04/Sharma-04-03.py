# Sharma, Sagar
# 1001-626-958
# 2019-12-02
# Assignment-04-03

#reference ; https://machinelearningmastery.com/tutorial-first-neural-network-python-keras/
import pytest
import numpy as np
from cnn import CNN
import os

from numpy import loadtxt
from keras.models import Sequential
from keras.layers import Dense

def test_train_evaluate():
    print('inside')
    # define the keras model
    # load the dataset
    dataset = loadtxt('pima-indians-diabetes.txt', delimiter=',')
    # split into input (X) and output (y) variables
    X = dataset[:,0:8]
    y = dataset[:,8]
    # define the keras model
    model = Sequential()
    model.add(Dense(12, input_dim=8, activation='relu'))
    model.add(Dense(8, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    # compile the keras model
    model.compile(loss='mean_squared_error', optimizer="SGD", metrics=['accuracy'])
    # fit the keras model on the dataset
    model.fit(X, y, epochs=150, batch_size=10)
    # evaluate the keras model
    _, accuracy = model.evaluate(X, y)
    # print('Accuracy: %.2f' % (accuracy*100))
    my_cnn = CNN()
    my_cnn.add_input_layer(shape = (8,))
    my_cnn.append_dense_layer(num_nodes=12,activation="relu")
    my_cnn.append_dense_layer(num_nodes=8,activation="relu")
    my_cnn.append_dense_layer(num_nodes=12,activation="sigmoid")
    my_cnn.set_loss_function(loss = "mean_squared_error")
    my_cnn.set_optimizer(optimizer = "sgd")
    my_cnn.set_metric(metric = "accuracy")
    my_cnn.train(X_train = X, y_train = y, num_epochs = 10, batch_size = 10)
    acc = my_cnn.evaluate(X = X, y = y)
    assert (acc == accuracy)
